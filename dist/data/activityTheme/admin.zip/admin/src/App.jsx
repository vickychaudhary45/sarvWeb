import { useState } from 'react'
import Button from '@mui/material/Button'
import './App.css'
import { makeStyles } from '@mui/material'

const adminStyle = makeStyles(()=>({

}))

function App() {
  const [count, setCount] = useState(0)

  return (
    <div className="App">
        <Button variant="contained">Hello world</Button>
    </div>
  )
}

export default App
